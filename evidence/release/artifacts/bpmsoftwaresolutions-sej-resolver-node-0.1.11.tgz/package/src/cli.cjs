#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');

const resolver = require('./resolver.cjs');

function parseArgs(argv) {
  const args = {
    command: argv[0] || null,
    flags: {},
  };

  for (let index = 1; index < argv.length; index += 1) {
    const token = argv[index];
    if (!token.startsWith('--')) {
      throw new Error(`Unexpected positional argument: ${token}`);
    }

    const equalsIndex = token.indexOf('=');
    if (equalsIndex >= 0) {
      args.flags[token.slice(2, equalsIndex)] = token.slice(equalsIndex + 1);
      continue;
    }

    const key = token.slice(2);
    const next = argv[index + 1];
    if (!next || next.startsWith('--')) {
      args.flags[key] = true;
      continue;
    }

    args.flags[key] = next;
    index += 1;
  }

  return args;
}

function readJson(filePath) {
  if (typeof filePath !== 'string' || filePath.length === 0) {
    throw new Error('A JSON file path is required.');
  }
  return JSON.parse(fs.readFileSync(path.resolve(filePath), 'utf8'));
}

function usage() {
  return [
    'Usage:',
    '  sej-resolver resolve --sej <path> [--input <path>]',
    '  sej-resolver resolve --contract <path> [--input <path>]',
    '  sej-resolver facade:generate --sej <path> [--input <path>]',
  ].join('\n');
}

function loadInvocation(command, flags) {
  const sejPath = flags.sej || flags.fixture;
  const contractPath = flags.contract;
  if (command === 'facade:generate' && !sejPath) {
    throw new Error('facade:generate requires --sej <path>.');
  }
  if (!sejPath && !contractPath) {
    throw new Error('Provide --sej <path> or --contract <path>.');
  }

  const source = readJson(sejPath || contractPath);
  const contract = source.contract || source;
  const input = flags.input ? readJson(flags.input) : (source.input || {});
  const options = source.options || {};
  options.context = {
    ...(options.context || {}),
    ...(sejPath ? { sourceSejPath: path.normalize(sejPath).replace(/\\/g, '/') } : {}),
  };
  return { contract, input, options };
}

function main() {
  const { command, flags } = parseArgs(process.argv.slice(2));
  if (!command || flags.help || flags.h) {
    process.stdout.write(`${usage()}\n`);
    return 0;
  }
  if (command !== 'resolve' && command !== 'facade:generate') {
    throw new Error(`Unsupported command: ${command}`);
  }

  const invocation = loadInvocation(command, flags);
  const result = resolver.resolveContract(invocation.contract, invocation.input, invocation.options);
  process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
  return result.status === resolver.STATUS.PASSED ? 0 : 1;
}

try {
  process.exitCode = main();
} catch (error) {
  const result = resolver.failClosed('cli_error', error.message || String(error));
  process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
  process.exitCode = 1;
}
