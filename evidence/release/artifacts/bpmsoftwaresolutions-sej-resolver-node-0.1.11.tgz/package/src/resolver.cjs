'use strict';

const fs = require('node:fs');
const crypto = require('node:crypto');
const path = require('node:path');

const { createDtoResolver } = require('./dto_resolver.cjs');
const { createPrimitiveHandlers } = require('./primitive_handlers/index.cjs');

const STATUS = Object.freeze({
  PASSED: 'passed',
  BLOCKED: 'blocked',
  FAILED: 'failed',
  SKIPPED: 'skipped',
});

const MISSING = Symbol('missing_reference');

function canonicalJson(value) {
  if (Array.isArray(value)) {
    return `[${value.map((item) => canonicalJson(item)).join(',')}]`;
  }
  if (isObject(value)) {
    return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(',')}}`;
  }
  return JSON.stringify(value);
}

function sha256Json(value) {
  return `sha256:${crypto.createHash('sha256').update(canonicalJson(value), 'utf8').digest('hex')}`;
}

function repoPath(relativePath) {
  let current = process.cwd();
  for (let index = 0; index < 8; index += 1) {
    const candidate = path.join(current, relativePath);
    if (fs.existsSync(candidate)) return candidate;
    const parent = path.dirname(current);
    if (parent === current) break;
    current = parent;
  }
  return path.resolve(relativePath);
}

function loadResolverAuthority() {
  return JSON.parse(fs.readFileSync(repoPath('contracts/resolver-authority/loc-sej-resolver-collapse-authority-pack.v1.json'), 'utf8'));
}

const RESOLVER_AUTHORITY = loadResolverAuthority();
const AUTHORITY = RESOLVER_AUTHORITY.authority;
const DTO_RESOLVER = createDtoResolver({ authority: AUTHORITY, missing: MISSING });
const {
  asArray,
  evaluatePredicate,
  hasOwn,
  isMissing,
  isObject,
  projectValue,
  readPointer,
  resolveReference,
  resolveValue,
  shapeResult,
  validate: validateProjectedOutputShape,
} = DTO_RESOLVER;
const FAIL_CLOSED_PROJECTION = RESOLVER_AUTHORITY.projectionContracts['loc.sej.resolver.fail-closed.from-reason.projection.v1'].projection;
const OPERATION_STATE_PROJECTION = RESOLVER_AUTHORITY.projectionContracts['loc.sej.resolver.operation-state.from-runtime.projection.v1'].projection;

function failClosed(code, message, details) {
  const operationState = { blocker: code, message, details: details || {} };
  return shapeResult(projectValue(FAIL_CLOSED_PROJECTION, {
    contract: {},
    input: {},
    context: { operationState },
    constants: {},
    steps: {},
  }));
}

function createState(contract, input, options) {
  return {
    contract,
    input: input === undefined ? {} : input,
    context: isObject(options.context) ? options.context : {},
    constants: isObject(contract.constants) ? contract.constants : {},
    steps: {},
  };
}

function dispatchOperation(operation, payload, state, helpers) {
  const primitiveHandlers = createPrimitiveHandlers();
  if (hasOwn(primitiveHandlers, operation)) {
    return primitiveHandlers[operation](payload, state, helpers);
  }
  throw new Error(`Unsupported primitive operation: ${operation}`);
}

function executeStage(step, state, helpers) {
  if (!isObject(step)) return failClosed('invalid_step', 'Each stage must be an object.', { step });
  const stageCatalog = AUTHORITY.stageTypeCatalog;
  const stepType = step.type || stageCatalog.defaultStageType;
  const stepId = step.id || step.key || String(Object.keys(state.steps).length);
  const stageConfig = asArray(stageCatalog.stageTypes).find((item) => item.stageType === stepType)
    || stageCatalog.unsupportedStageType;

  if (stageConfig.mode === 'blocked') return failClosed(stageConfig.blocker, renderAuthorityTemplate(AUTHORITY.messageCatalog.messages[stageConfig.messageKey] || '', { stepType }), { stepId });
  if (stageConfig.mode === 'resolve_return_value') {
    const result = resolveValue(step.ref || step.value || step.result, state);
    if (isMissing(result)) return failClosed('missing_reference', 'Reference could not be resolved.', { stepId, reference: step.ref || step.value || step.result });
    state.steps[stepId] = result;
    return shapeResult({ result });
  }

  let result;
  if (stageConfig.mode === 'dispatch_declared_primitive') {
    const operation = asArray(stageConfig.operationFieldPriority).map((field) => step[field]).find(Boolean) || stageConfig.operation;
    const payload = step.payload || step.spec || step;
    if (operation === 'resolve.reference.v1') {
      const resolved = resolveReference(payload, state);
      if (isMissing(resolved)) {
        return failClosed('missing_reference', 'Reference could not be resolved.', { stepId, reference: payload });
      }
      result = resolved;
    } else {
      result = dispatchOperation(operation, payload, state, helpers);
      if (isObject(result) && (result.status === STATUS.BLOCKED || result.status === STATUS.FAILED) && (result.blocker || result.error)) {
        return shapeResult(result);
      }
    }
  } else if (stageConfig.mode === 'project_value') {
    result = projectValue(step.spec || step.mapping || step.resultMapping || step, state);
    if (isMissing(result)) return failClosed('missing_reference', 'Reference could not be resolved.', { stepId });
  } else {
    return failClosed(stageCatalog.unsupportedStageType.blocker, renderAuthorityTemplate(AUTHORITY.messageCatalog.messages[stageCatalog.unsupportedStageType.messageKey], { stepType }), { stepId });
  }

  if (isMissing(result)) {
    return failClosed('missing_reference', 'Reference could not be resolved.', { stepId });
  }
  state.steps[stepId] = result;
  return shapeResult({ result });
}

function executeStages(contract, state) {
  const helpers = {
    resolveReference,
    resolveValue,
    evaluatePredicate,
    projectValue,
    dispatchOperation,
    executeStage: (step) => executeStage(step, state, helpers),
    resolveContract: (nextContract, nextInput, nextOptions) => resolveContract(nextContract, nextInput, nextOptions),
  };
  let last = shapeResult({ result: null });
  for (const step of asArray(contract.steps || contract.stages)) {
    last = executeStage(step, state, helpers);
    if (last.status === STATUS.BLOCKED || last.status === STATUS.FAILED) return last;
  }
  return last;
}

function resolveReturn(spec, state) {
  if (!isObject(spec)) return resolveValue(spec, state);
  if (spec.type === 'step') return resolveValue(spec.ref, state);
  if (spec.type === 'value') return resolveValue(spec.value, state);
  return resolveValue(spec, state);
}

function firstObject(...values) {
  return values.find((value) => isObject(value)) || null;
}

function getDeclaredContract(container, key, fieldName, pluralFieldName) {
  const plural = isObject(container[pluralFieldName]) ? container[pluralFieldName] : {};
  if (isObject(plural[key])) return plural[key];
  const singular = isObject(container[fieldName]) ? container[fieldName] : null;
  if (singular && (!singular[`${fieldName}Key`] || singular[`${fieldName}Key`] === key || singular.dtoContractKey === key || singular.projectionContractKey === key)) {
    return singular;
  }
  return null;
}

function readDottedPath(root, dottedPath) {
  const parts = String(dottedPath || '').split('.').filter(Boolean);
  return readPointer(root, parts);
}

function buildProjectionEvidence(config, status, declaration, projectedShape, secondaryShape, unsupportedReason) {
  const evidence = {
    schemaVersion: config.evidenceSchemaVersion,
    status,
    resolverPackage: config.resolverPackage,
    resolverLanguage: 'node',
  };
  for (const [evidenceKey, declarationKey] of Object.entries(config.declarationFields)) {
    evidence[evidenceKey] = declaration[declarationKey] || null;
  }
  if (config.sourceField) evidence[config.sourceField] = declaration[config.sourceField] || null;
  evidence[config.primaryHashField] = projectedShape === null || projectedShape === undefined ? null : sha256Json(projectedShape);
  if (config.secondaryHashField) evidence[config.secondaryHashField] = secondaryShape === null || secondaryShape === undefined ? null : sha256Json(secondaryShape);
  evidence[config.unsupportedEvidenceField] = unsupportedReason || null;
  return evidence;
}

function buildProjectionHandle(config, status, declaration, projectedShape, secondaryShape, unsupportedReason) {
  const evidence = buildProjectionEvidence(config, status, declaration, projectedShape, secondaryShape, unsupportedReason);
  const handle = {};
  for (const handleKey of config.handleDeclarationFields) handle[handleKey] = evidence[handleKey];
  handle[config.primaryShapeField] = projectedShape === undefined ? config.emptyPrimaryShape : projectedShape;
  if (config.secondaryShapeField) handle[config.secondaryShapeField] = secondaryShape === undefined ? config.emptySecondaryShape : secondaryShape;
  handle[config.evidenceField] = evidence;
  handle[config.unsupportedHandleField] = unsupportedReason || null;
  return handle;
}

function failProjectionWith(config, reason, declaration, details) {
  const handle = buildProjectionHandle(config, STATUS.BLOCKED, declaration || {}, null, null, reason);
  return shapeResult({
    status: STATUS.BLOCKED,
    blocker: reason,
    error: `${config.failureLabel} failed closed: ${reason}`,
    result: handle,
    evidence: {
      [config.evidenceField]: handle[config.evidenceField],
      details: details || {},
    },
    findings: [
      {
        severity: 'blocker',
        code: reason,
        message: `${config.failureLabel} failed closed: ${reason}`,
        details: details || {},
      },
    ],
  });
}

const DTO_PROJECTION = Object.freeze({
  ...AUTHORITY.projectionFamilies.dtoProjection,
  resolverPackage: AUTHORITY.resolverPackageBindings.node,
  failureLabel: 'DTO projection',
});

function failProjection(reason, declaration, details) {
  return failProjectionWith(DTO_PROJECTION, reason, declaration, details);
}

function resolveProjectionSource(projectionSource, declaration, operationState) {
  const sourceConfig = asArray(AUTHORITY.projectionSourceCatalog.sources).find((source) => source.projectionSource === projectionSource);
  if (!sourceConfig) return readDottedPath(operationState, projectionSource);
  if (sourceConfig.path) return readDottedPath({ operationState }, String(sourceConfig.path).replace(/^\$/, '').replace(/^\./, ''));
  for (const field of asArray(sourceConfig.pathFromDeclarationFields)) {
    if (declaration[field]) return readDottedPath(operationState, String(declaration[field]).replace(/^\//, '').replace(/\//g, '.'));
  }
  return MISSING;
}

const RUNTIME_DEPENDENCY_PROJECTION = AUTHORITY.runtimeDependencyProjection;
const RUNTIME_FACT_KINDS = RUNTIME_DEPENDENCY_PROJECTION.factKinds;

function buildOperationState(input, options, state, last, baseResult, envelopeResult = false) {
  const context = isObject(options.context) ? options.context : {};
  return projectValue(OPERATION_STATE_PROJECTION, {
    contract: {},
    input: {},
    context: {
      operationState: {
        inputValue: input,
        context,
        state,
        last,
        baseResult,
        envelopeResult,
      },
    },
    constants: {},
    steps: {},
  });
}

function validateRuntimeDependencyFacts(facts) {
  const contract = RESOLVER_AUTHORITY.dtoContracts[RUNTIME_DEPENDENCY_PROJECTION.factInputContractKey];
  const itemContract = RESOLVER_AUTHORITY.dtoContracts[contract.itemsShapeRef];
  if (!Array.isArray(facts)) return false;
  return facts.every((fact) => {
    if (!validateProjectedOutputShape(itemContract, fact)) return false;
    const requiredValueField = factKindConfig(fact).requiredValueField;
    return Boolean(requiredValueField && fact[requiredValueField]);
  });
}

function readPath(root, dottedPath) {
  return readPointer(root, String(dottedPath || '').split('.').filter(Boolean));
}

function renderAuthorityTemplate(template, scope) {
  return String(template).replace(/\{\{([^}]+)\}\}/g, (_, expression) => {
    const options = expression.split('|').map((part) => part.trim()).filter(Boolean);
    for (const option of options) {
      const value = option.includes('.') ? readPath(scope, option) : scope.fact?.[option] ?? scope.node?.[option] ?? scope[option];
      if (!isMissing(value) && value !== undefined && value !== null && value !== '') return String(value);
    }
    return options[options.length - 1] || '';
  });
}

function factKindConfig(fact) {
  return RUNTIME_FACT_KINDS[fact.kind] || {};
}

function projectRuntimeImportField(fieldSpec, fact) {
  if (fieldSpec.overrideField && fact[fieldSpec.overrideField] !== undefined) return fact[fieldSpec.overrideField];
  if (fieldSpec.from) return fact[fieldSpec.from];
  if (fieldSpec.fromCatalog) return fact[fieldSpec.fromCatalog] || factKindConfig(fact)[fieldSpec.fromCatalog];
  if (fieldSpec.template) return renderAuthorityTemplate(fieldSpec.template, { fact });
  return undefined;
}

function runtimeGraphNodeKey(fact) {
  if (fact.graphNodeKey) return fact.graphNodeKey;
  return renderAuthorityTemplate(factKindConfig(fact).nodeKeyTemplate || 'runtime_path:{{path}}', { fact });
}

function contractRuntimeRootKey(contract) {
  const root = RUNTIME_DEPENDENCY_PROJECTION.dependencyGraph.rootNode;
  for (const field of root.nodeKeyFromContractFields || []) {
    if (contract[field]) return contract[field];
  }
  return root.fallback;
}

function compactObject(entries) {
  return Object.fromEntries(entries.filter(([, value]) => value !== undefined && value !== null));
}

function projectRuntimeImports(facts) {
  return facts.map((fact) => compactObject(RUNTIME_DEPENDENCY_PROJECTION.importFieldProjection.map((fieldSpec) => [
    fieldSpec.field,
    projectRuntimeImportField(fieldSpec, fact),
  ])));
}

function buildRuntimeDependencyGraph(contract, facts) {
  const graphAuthority = RUNTIME_DEPENDENCY_PROJECTION.dependencyGraph;
  const contractKey = contractRuntimeRootKey(contract);
  const nodesByKey = new Map([[contractKey, { nodeKey: contractKey, nodeType: graphAuthority.rootNode.nodeType }]]);
  const edges = [];

  for (const fact of facts) {
    const nodeKey = runtimeGraphNodeKey(fact);
    if (!nodesByKey.has(nodeKey)) {
      const kindConfig = factKindConfig(fact);
      nodesByKey.set(nodeKey, compactObject([
        ['nodeKey', nodeKey],
        ['nodeType', fact.graphNodeType || kindConfig.graphNodeType],
        ['graphRole', kindConfig.graphRole],
      ]));
    }
    const node = nodesByKey.get(nodeKey);
    edges.push(...graphAuthority.edgeTemplates.map((edgeTemplate) => ({
      from: renderAuthorityTemplate(edgeTemplate.from, { fact, node, contractKey }),
      to: renderAuthorityTemplate(edgeTemplate.to, { fact, node, contractKey }),
      edgeType: renderAuthorityTemplate(edgeTemplate.edgeType, { fact, node, contractKey }),
    })));
  }

  return {
    schemaVersion: graphAuthority.schemaVersion,
    nodes: Array.from(nodesByKey.values()),
    edges,
  };
}

function validateRuntimeImportProjectionShape(runtimeImportContract, projectedRuntimeImports, projectedRuntimeDependencyGraph) {
  const requiredFields = Array.isArray(runtimeImportContract.requiredFields) ? runtimeImportContract.requiredFields : [];
  const handleShape = { projectedRuntimeImports, projectedRuntimeDependencyGraph };
  if (requiredFields.length && !requiredFields.every((field) => hasOwn(handleShape, field))) return false;
  return Array.isArray(projectedRuntimeImports)
    && isObject(projectedRuntimeDependencyGraph)
    && Array.isArray(projectedRuntimeDependencyGraph.nodes)
    && Array.isArray(projectedRuntimeDependencyGraph.edges);
}

const RUNTIME_IMPORT_PROJECTION = Object.freeze({
  ...AUTHORITY.projectionFamilies.runtimeImportProjection,
  resolverPackage: AUTHORITY.resolverPackageBindings.node,
  failureLabel: 'Runtime import projection',
});

function failRuntimeImportProjection(reason, declaration, details) {
  return failProjectionWith(RUNTIME_IMPORT_PROJECTION, reason, declaration, details);
}

function applyRuntimeImportProjection(contract, input, options, state, last, baseResult) {
  const declaration = contract.runtimeImportProjection;
  if (!isObject(declaration)) return null;

  const projectionDeclaration = {
    ...declaration,
    runtimeDependencySource: declaration.runtimeDependencySource || 'operationState.runtimeDependencyFacts',
  };
  const runtimeImportContractKey = projectionDeclaration.runtimeImportContractKey;
  const runtimeImportProjectionKey = projectionDeclaration.runtimeImportProjectionKey;
  const runtimeDependencySource = projectionDeclaration.runtimeDependencySource;

  if (!runtimeImportContractKey) return failRuntimeImportProjection('runtime_import_contract_missing', projectionDeclaration, { field: 'runtimeImportContractKey' });
  if (!runtimeImportProjectionKey) return failRuntimeImportProjection('runtime_import_projection_contract_missing', projectionDeclaration, { field: 'runtimeImportProjectionKey' });

  const runtimeImportContract = getDeclaredContract(contract, runtimeImportContractKey, 'runtimeImportContract', 'runtimeImportContracts');
  if (!runtimeImportContract) return failRuntimeImportProjection('runtime_import_contract_missing', projectionDeclaration, { runtimeImportContractKey });

  const runtimeImportProjectionContract = getDeclaredContract(contract, runtimeImportProjectionKey, 'runtimeImportProjectionContract', 'runtimeImportProjectionContracts');
  if (!runtimeImportProjectionContract) return failRuntimeImportProjection('runtime_import_projection_contract_missing', projectionDeclaration, { runtimeImportProjectionKey });

  const operationState = buildOperationState(input, options, state, last, baseResult);
  const facts = resolveProjectionSource(runtimeDependencySource, projectionDeclaration, operationState);
  if (isMissing(facts)) return failRuntimeImportProjection('runtime_dependency_source_missing', projectionDeclaration, { runtimeDependencySource });
  if (!validateRuntimeDependencyFacts(facts)) return failRuntimeImportProjection('runtime_dependency_fact_shape_invalid', projectionDeclaration, { runtimeDependencySource });

  let projectedRuntimeImports;
  let projectedRuntimeDependencyGraph;
  try {
    projectedRuntimeImports = projectRuntimeImports(facts);
    projectedRuntimeDependencyGraph = buildRuntimeDependencyGraph(contract, facts);
  } catch (error) {
    return failRuntimeImportProjection('runtime_import_projection_operation_unsupported', projectionDeclaration, { message: error.message || String(error) });
  }

  if (!validateRuntimeImportProjectionShape(runtimeImportContract, projectedRuntimeImports, projectedRuntimeDependencyGraph)) {
    return failRuntimeImportProjection('projected_runtime_import_shape_invalid', projectionDeclaration, { runtimeImportContractKey });
  }

  const handle = buildProjectionHandle(RUNTIME_IMPORT_PROJECTION, STATUS.PASSED, projectionDeclaration, projectedRuntimeImports, projectedRuntimeDependencyGraph, null);
  return shapeResult({
    status: STATUS.PASSED,
    result: handle,
    evidence: {
      contractKey: contract.contractKey || contract.semanticModuleKey || null,
      stageCount: asArray(contract.steps || contract.stages).length,
      executedStageIds: Object.keys(state.steps),
      resolverRuntimeImportProjectionEvidence: handle.resolverRuntimeImportProjectionEvidence,
    },
  });
}

function applyResultProjection(contract, input, options, state, last, baseResult) {
  const declaration = contract.resultProjection;
  if (!isObject(declaration)) {
    return null;
  }

  const dtoContractKey = declaration.dtoContractKey;
  const projectionContractKey = declaration.projectionContractKey;
  const projectionSource = declaration.projectionSource || 'operationState';
  const projectionDeclaration = { ...declaration, projectionSource };

  if (!dtoContractKey) return failProjection('dto_contract_missing', projectionDeclaration, { field: 'dtoContractKey' });
  if (!projectionContractKey) return failProjection('projection_contract_missing', projectionDeclaration, { field: 'projectionContractKey' });

  const dtoContract = getDeclaredContract(contract, dtoContractKey, 'dtoContract', 'dtoContracts');
  if (!dtoContract) return failProjection('dto_contract_missing', projectionDeclaration, { dtoContractKey });

  const projectionContract = getDeclaredContract(contract, projectionContractKey, 'projectionContract', 'projectionContracts');
  if (!projectionContract) return failProjection('projection_contract_missing', projectionDeclaration, { projectionContractKey });

  const operationState = buildOperationState(input, options, state, last, baseResult, true);
  const source = resolveProjectionSource(projectionSource, projectionDeclaration, operationState);
  if (isMissing(source)) return failProjection('projection_source_missing', projectionDeclaration, { projectionSource });

  const projectionSpec = firstObject(
    declaration.projection,
    declaration.spec,
    projectionContract.projection,
    projectionContract.spec,
    projectionContract.mapping,
    projectionContract.projectedOutputShape,
  );
  if (!projectionSpec) return failProjection('projection_contract_invalid', projectionDeclaration, { projectionContractKey });

  const projectionState = {
    contract,
    input: source,
    context: {
      operationState,
      stageResult: operationState.stageResult,
      resolverState: operationState.resolverState,
      adapterResult: operationState.adapterResult,
      invocation: input,
    },
    constants: state.constants,
    steps: state.steps,
  };
  let projectedOutputShape;
  try {
    projectedOutputShape = projectValue(projectionSpec, projectionState);
  } catch (error) {
    return failProjection('projection_operation_unsupported', projectionDeclaration, { message: error.message || String(error) });
  }
  if (isMissing(projectedOutputShape)) return failProjection('projection_source_missing', projectionDeclaration, { projectionSource });
  if (!validateProjectedOutputShape(dtoContract, projectedOutputShape)) {
    return failProjection('projected_output_shape_invalid', projectionDeclaration, { dtoContractKey });
  }

  return shapeResult({
    status: STATUS.PASSED,
    result: buildProjectionHandle(DTO_PROJECTION, STATUS.PASSED, projectionDeclaration, projectedOutputShape, null, null),
    evidence: {
      contractKey: contract.contractKey || contract.semanticModuleKey || null,
      stageCount: asArray(contract.steps || contract.stages).length,
      executedStageIds: Object.keys(state.steps),
      resolverProjectionEvidence: buildProjectionEvidence(DTO_PROJECTION, STATUS.PASSED, projectionDeclaration, projectedOutputShape, null, null),
    },
  });
}

function resolveContract(contract, input, options) {
  if (!isObject(contract)) {
    return failClosed('contract_missing', 'A SEJ contract object is required.');
  }
  const state = createState(contract, input, isObject(options) ? options : {});
  const last = executeStages(contract, state);
  if (last.status === STATUS.BLOCKED || last.status === STATUS.FAILED) return last;
  const baseResult = resolveReturn(contract.return || { type: 'step', ref: '$steps' }, state);
  const runtimeImportProjected = applyRuntimeImportProjection(contract, input, isObject(options) ? options : {}, state, last, baseResult);
  if (runtimeImportProjected) return runtimeImportProjected;
  const projected = applyResultProjection(contract, input, isObject(options) ? options : {}, state, last, baseResult);
  if (projected) return projected;
  return shapeResult({
    status: STATUS.PASSED,
    result: baseResult,
    evidence: {
      contractKey: contract.contractKey || contract.semanticModuleKey || null,
      stageCount: asArray(contract.steps || contract.stages).length,
      executedStageIds: Object.keys(state.steps),
    },
  });
}

function resolver(contractKey) {
  return {
    execute(invocation = {}, options = {}) {
      const contract = isObject(options.contract) ? options.contract : invocation.contract;
      return resolveContract(contract, invocation.input || invocation, options);
    },
  };
}

function readFixture(fixturePath) {
  return JSON.parse(fs.readFileSync(fixturePath, 'utf8'));
}

function main() {
  const fixturePath = process.argv[2];
  if (!fixturePath) {
    process.stdout.write(`${JSON.stringify(failClosed('input_missing', 'Provide a fixture path.'), null, 2)}\n`);
    process.exitCode = 1;
    return;
  }
  const fixture = readFixture(path.resolve(fixturePath));
  const result = resolveContract(fixture.contract, fixture.input, {});
  process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
  process.exitCode = result.status === STATUS.PASSED ? 0 : 1;
}

module.exports = {
  STATUS,
  failClosed,
  resolveReference,
  resolveValue,
  evaluatePredicate,
  projectValue,
  dispatchOperation,
  executeStages,
  resolveContract,
  resolver,
  shapeResult,
  primitiveHandlers: createPrimitiveHandlers(),
};

if (require.main === module) {
  try {
    main();
  } catch (error) {
    process.stdout.write(`${JSON.stringify(failClosed('runtime_exception', error.message || String(error)), null, 2)}\n`);
    process.exitCode = 1;
  }
}
