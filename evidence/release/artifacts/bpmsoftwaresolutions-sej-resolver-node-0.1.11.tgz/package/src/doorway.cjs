'use strict';

const fs = require('node:fs');
const path = require('node:path');

const resolver = require('./resolver.cjs');

function readJson(filePath) {
  if (typeof filePath !== 'string' || filePath.length === 0) {
    throw new Error('A sourceSej path is required.');
  }
  return JSON.parse(fs.readFileSync(path.resolve(filePath), 'utf8'));
}

function run(invocation = {}) {
  const sourceSej = invocation.sourceSej;
  const source = readJson(sourceSej);
  const contract = source.contract || source;
  const argv = Array.isArray(invocation.argv) ? invocation.argv : process.argv.slice(2);
  const stdin = Object.prototype.hasOwnProperty.call(invocation, 'stdin')
    ? invocation.stdin
    : (process.stdin.isTTY ? '' : fs.readFileSync(0, 'utf8'));
  const input = Object.prototype.hasOwnProperty.call(invocation, 'input')
    ? invocation.input
    : {
      ...(isObject(source.input) ? source.input : {}),
      argv,
      stdin,
    };
  const options = {
    ...(source.options || {}),
    ...(invocation.options || {}),
  };
  options.context = {
    ...((source.options || {}).context || {}),
    ...((invocation.options || {}).context || {}),
    toolKey: invocation.toolKey || null,
    argv,
    stdin,
    sourceSejPath: path.normalize(sourceSej).replace(/\\/g, '/'),
  };

  const result = resolver.resolveContract(contract, input, options);
  if (!invocation.silent) {
    process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
  }
  if (result.status !== resolver.STATUS.PASSED) {
    process.exitCode = 1;
  }
  return result;
}

module.exports = {
  run,
};

function isObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}
