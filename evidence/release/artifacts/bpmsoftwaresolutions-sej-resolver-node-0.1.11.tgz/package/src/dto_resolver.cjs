'use strict';

function createDtoResolver({ authority, missing }) {
  function isObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function hasOwn(object, key) {
    return Object.prototype.hasOwnProperty.call(object, key);
  }

  function asArray(value) {
    return Array.isArray(value) ? value : [];
  }

  function isMissing(value) {
    return value === missing;
  }

  function shapeResult(value) {
    const source = isObject(value) ? value : { result: value };
    return {
      status: source.status || 'passed',
      result: hasOwn(source, 'result') ? source.result : null,
      evidence: isObject(source.evidence) ? source.evidence : {},
      findings: Array.isArray(source.findings) ? source.findings : [],
      blocker: source.blocker || null,
      error: source.error || null,
    };
  }

  function readPointer(root, parts) {
    let current = root;
    for (const part of parts) {
      if (current === null || current === undefined) return missing;
      if (Array.isArray(current)) {
        const index = Number(part);
        if (!Number.isInteger(index) || index < 0 || index >= current.length) return missing;
        current = current[index];
        continue;
      }
      if (!isObject(current) || !hasOwn(current, part)) return missing;
      current = current[part];
    }
    return current;
  }

  function resolveReference(reference, state) {
    if (!String(reference).startsWith('$')) return reference;
    const rootAuthority = authority.referenceRoots;
    const declaredRoot = asArray(rootAuthority.roots).find((root) => root.token === reference);
    if (declaredRoot) return readPointer({ state }, String(declaredRoot.path).replace(/^\$\.?/, '').split('.').filter(Boolean));

    const parts = String(reference).slice(1).split('.').filter(Boolean);
    if (!parts.length) return state;

    const rootName = parts.shift();
    const rootPath = rootAuthority.dottedReferenceRootMap[rootName];
    if (!rootPath) return missing;
    const root = readPointer({ state }, String(rootPath).replace(/^\$\.?/, '').split('.').filter(Boolean));
    return isMissing(root) ? missing : readPointer(root, parts);
  }

  function resolveValue(value, state) {
    if (typeof value === 'string') {
      return value.startsWith('$') ? resolveReference(value, state) : value;
    }
    if (Array.isArray(value)) {
      const projected = [];
      for (const item of value) {
        const resolved = resolveValue(item, state);
        if (isMissing(resolved)) return missing;
        projected.push(resolved);
      }
      return projected;
    }
    if (!isObject(value)) return value;
    if (hasOwn(value, 'const')) return value.const;
    if (hasOwn(value, 'literal')) return value.literal;
    if (hasOwn(value, 'ref')) return resolveReference(value.ref, state);
    if (hasOwn(value, '$ref')) return resolveReference(value.$ref, state);
    if (hasOwn(value, 'selector')) return resolveReference(value.selector, state);
    if (hasOwn(value, '$context')) return resolveReference(`$context.${value.$context}`, state);
    if (hasOwn(value, '$from')) {
      const from = String(value.$from || '');
      const resolved = resolveReference(from.startsWith('$') ? from : `$context.${from}`, state);
      if (isMissing(resolved) && hasOwn(value, 'default')) return value.default;
      return resolved;
    }
    if (hasOwn(value, 'value') && Object.keys(value).length === 1) {
      return resolveValue(value.value, state);
    }
    const projected = {};
    for (const [key, item] of Object.entries(value)) {
      const resolved = resolveValue(item, state);
      if (isMissing(resolved)) return missing;
      projected[key] = resolved;
    }
    return projected;
  }

  function deepEqual(left, right) {
    if (Object.is(left, right)) return true;
    if (Array.isArray(left) && Array.isArray(right)) {
      return left.length === right.length && left.every((item, index) => deepEqual(item, right[index]));
    }
    if (isObject(left) && isObject(right)) {
      const leftKeys = Object.keys(left).sort();
      const rightKeys = Object.keys(right).sort();
      if (!deepEqual(leftKeys, rightKeys)) return false;
      return leftKeys.every((key) => deepEqual(left[key], right[key]));
    }
    return false;
  }

  function exists(value) {
    return value !== undefined && value !== null && !isMissing(value);
  }

  function evaluatePredicate(predicate, state) {
    if (typeof predicate === 'boolean') return predicate;
    if (predicate === null || predicate === undefined) return false;
    if (typeof predicate === 'string') {
      const resolved = resolveValue(predicate, state);
      return isMissing(resolved) ? missing : Boolean(resolved);
    }
    if (!isObject(predicate)) return Boolean(predicate);
    if (hasOwn(predicate, 'equals')) {
      const [left, right] = resolveValue(predicate.equals, state);
      if (isMissing(left) || isMissing(right)) return missing;
      return deepEqual(left, right);
    }
    if (hasOwn(predicate, 'notEquals')) {
      const [left, right] = resolveValue(predicate.notEquals, state);
      if (isMissing(left) || isMissing(right)) return missing;
      return !deepEqual(left, right);
    }
    if (hasOwn(predicate, 'exists')) {
      const resolved = resolveValue(predicate.exists, state);
      return isMissing(resolved) ? missing : exists(resolved);
    }
    if (hasOwn(predicate, 'missing')) {
      const resolved = resolveValue(predicate.missing, state);
      return isMissing(resolved) ? missing : !exists(resolved);
    }
    if (hasOwn(predicate, 'not')) {
      const evaluated = evaluatePredicate(predicate.not, state);
      return isMissing(evaluated) ? missing : !evaluated;
    }
    if (hasOwn(predicate, 'allOf')) {
      for (const item of asArray(predicate.allOf)) {
        const evaluated = evaluatePredicate(item, state);
        if (isMissing(evaluated)) return missing;
        if (!evaluated) return false;
      }
      return true;
    }
    if (hasOwn(predicate, 'anyOf')) {
      let sawMissing = false;
      for (const item of asArray(predicate.anyOf)) {
        const evaluated = evaluatePredicate(item, state);
        if (isMissing(evaluated)) {
          sawMissing = true;
          continue;
        }
        if (evaluated) return true;
      }
      return sawMissing ? missing : false;
    }
    if (hasOwn(predicate, 'noneOf')) {
      let sawMissing = false;
      for (const item of asArray(predicate.noneOf)) {
        const evaluated = evaluatePredicate(item, state);
        if (isMissing(evaluated)) {
          sawMissing = true;
          continue;
        }
        if (evaluated) return false;
      }
      return sawMissing ? missing : true;
    }
    return false;
  }

  function projectValue(spec, state) {
    if (!isObject(spec)) return resolveValue(spec, state);
    if (hasOwn(spec, 'when')) {
      const condition = evaluatePredicate(spec.when, state);
      if (isMissing(condition)) return missing;
      return condition
        ? projectValue(spec.then, state)
        : projectValue(spec.else, state);
    }
    if (hasOwn(spec, 'fields')) {
      const output = {};
      for (const [key, fieldSpec] of Object.entries(spec.fields || {})) {
        const resolved = projectValue(fieldSpec, state);
        if (isMissing(resolved)) return missing;
        output[key] = resolved;
      }
      return output;
    }
    return resolveValue(spec, state);
  }

  function validate(dtoContract, projectedOutputShape) {
    const requiredFields = Array.isArray(dtoContract.requiredFields)
      ? dtoContract.requiredFields
      : Array.isArray(dtoContract.fields)
        ? dtoContract.fields
            .filter((field) => isObject(field) ? field.required !== false : true)
            .map((field) => isObject(field) ? field.fieldKey : field)
        : [];
    if (!requiredFields.length) return true;
    if (!isObject(projectedOutputShape)) return false;
    return requiredFields.every((field) => hasOwn(projectedOutputShape, field));
  }

  return {
    asArray,
    evaluatePredicate,
    hasOwn,
    isMissing,
    isObject,
    projectValue,
    readPointer,
    resolveReference,
    resolveValue,
    shapeResult,
    validate,
  };
}

module.exports = { createDtoResolver };
